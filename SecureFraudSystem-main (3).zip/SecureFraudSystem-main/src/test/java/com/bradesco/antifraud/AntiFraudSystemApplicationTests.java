package com.bradesco.antifraud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AntiFraudSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
